﻿namespace bytebank.Titular
{
    public class Cliente
    {

        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string Profissao { get; set; }
    }
}
