﻿
namespace bytebank
{
    public class Cliente
    {

        public string cpf;
        public string nome;
        public string profissao;
     
    }
}
